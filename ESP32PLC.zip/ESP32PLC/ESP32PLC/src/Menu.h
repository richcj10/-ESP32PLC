#ifndef MENU_H
#define  MENU_H

void DislaySaver();
void DisplayTimeoutReset();
void DisplayManager();
void ButtonHandeler();
void DisplaySwitchCase();
void DispalySleepControl(char value);

#endif
